import pytest
from player import Player
from level import Level
import constants as SOKOBAN

# Integration Testing
@pytest.fixture
def level_fixture():
    # Initialize the Level class instance with the level number to be tested
    level = Level(1)  
    return level

@pytest.fixture
def player_fixture(level_fixture):
    player = Player()
    # Set the player's initial position to the player's position in the level
    player.pos = level_fixture.position_player  
    return player

def test_player_move_updates_level_structure(player_fixture, level_fixture):
    player = player_fixture
    level = level_fixture

    # Save the original state of the level's structure
    original_structure = level.structure

    # Move the player one step to the left
    player.move(SOKOBAN.K_LEFT, level, None)

    # Verify if the level's structure is updated correctly
    assert level.structure != original_structure

    # Verify if the player's position is updated correctly
    assert player.pos == [level.position_player[0] - 1, level.position_player[1]]
