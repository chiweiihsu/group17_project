import pytest
import constants as SOKOBAN
from copy import deepcopy
from player import Player

# Unit Testing
@pytest.fixture
def player_fixture():
    level = MockLevel()
    return Player(level)

class MockLevel:
    def __init__(self):
        self.structure = [
            [SOKOBAN.AIR, SOKOBAN.AIR, SOKOBAN.AIR],
            [SOKOBAN.AIR, SOKOBAN.PLAYER, SOKOBAN.AIR],
            [SOKOBAN.AIR, SOKOBAN.AIR, SOKOBAN.AIR]
        ]
        self.width = 3
        self.height = 3
        self.position_player = [1, 1]

def test_move_player_on_empty_case(player_fixture):
    player = player_fixture
    player.move(SOKOBAN.K_LEFT, MockLevel(), None)
    assert player.pos == [0, 1]

def test_move_player_push_box(player_fixture):
    player = player_fixture
    level = MockLevel()
    level.structure[1][0] = SOKOBAN.BOX
    player.move(SOKOBAN.K_LEFT, level, None)
    assert player.pos == [0, 1]
    assert level.structure[1][0] == SOKOBAN.AIR
    assert level.structure[1][2] == SOKOBAN.BOX

def test_move_player_push_box_to_target(player_fixture):
    player = player_fixture
    level = MockLevel()
    level.structure[1][0] = SOKOBAN.BOX
    level.structure[1][2] = SOKOBAN.TARGET
    player.move(SOKOBAN.K_LEFT, level, None)
    assert player.pos == [0, 1]
    assert level.structure[1][0] == SOKOBAN.AIR
    assert level.structure[1][2] == SOKOBAN.TARGET_FILLED
