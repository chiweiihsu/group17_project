Sokoban
========

A Sokoban game made with python and pygame

Build and Install
-----------------

### Dependencies
To run this game you'll need python3 and pygame installed

### How to run
```python3 Sokoban.py```
